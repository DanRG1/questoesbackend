<?php

// Read the number of test cases
$numberOfTestCases = intval(trim(fgets(STDIN)));

// Process each test case
for ($i = 0; $i < $numberOfTestCases; $i++) {
    // Read the coded message
    $codedMessage = trim(fgets(STDIN));

    // Extract the hidden text (uppercase letters) from the coded message
    $hiddenText = '';
    for ($j = 0; $j < strlen($codedMessage); $j++) {
        $char = $codedMessage[$j];
        if (ctype_upper($char)) {
            $hiddenText .= $char;
        }
    }

    // Print the extracted text
    echo $hiddenText . "\n";
}

?>
