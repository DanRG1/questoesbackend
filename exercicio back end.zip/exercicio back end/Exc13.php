<?php

while (true) {
    $input = readline();
    $values = explode(" ", $input);
    $Q = intval($values[0]);
    $D = intval($values[1]);
    $P = intval($values[2]);

    if ($Q == 0 && $D == 0 && $P == 0) {
        break;
    }

    $previous_pages_per_day = $Q * $D;
    $days_saved = $D;
    $new_pages_per_day = $P * ($previous_pages_per_day - $Q);
    $total_pages = $P * $new_pages_per_day;

    $result = $total_pages . " pagina";
    if ($total_pages != 1) {
        $result .= "s";
    }

    echo $result . PHP_EOL;
}

?>
