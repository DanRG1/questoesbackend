<?php

function verificarPremio($aposta, $sorteados) {
    $acertos = 0;
    foreach ($aposta as $numero) {
        if (in_array($numero, $sorteados)) {
            $acertos++;
        }
    }
    
    switch ($acertos) {
        case 3:
            return "terno";
        case 4:
            return "quadra";
        case 5:
            return "quina";
        case 6:
            return "sena";
        default:
            return "azar";
    }
}


$aposta = explode(" ", readline());


$sorteados = explode(" ", readline());

$premio = verificarPremio($aposta, $sorteados);


echo $premio;

?>

