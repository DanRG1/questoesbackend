<?php

// Function to determine the winner based on the given criteria
function determineWinner($match1, $match2) {
    $team1_goals = $match1[0] + $match2[1]; // Team 1 goals in both matches
    $team2_goals = $match1[1] + $match2[0]; // Team 2 goals in both matches

    $team1_score = ($team1_goals > $team2_goals) ? 3 : 0; // Team 1 score based on the number of goals
    $team2_score = ($team2_goals > $team1_goals) ? 3 : 0; // Team 2 score based on the number of goals

    $team1_score += ($team1_goals === $team2_goals && $match2[1] > $match1[0]) ? 1 : 0; // Team 1 score based on away goals
    $team2_score += ($team1_goals === $team2_goals && $match2[1] < $match1[0]) ? 1 : 0; // Team 2 score based on away goals

    if ($team1_score > $team2_score) {
        return "Time 1";
    } elseif ($team2_score > $team1_score) {
        return "Time 2";
    } else {
        return "Penaltis";
    }
}

// Read the number of test cases
$test_cases = intval(trim(fgets(STDIN)));

// Process each test case
for ($i = 1; $i <= $test_cases; $i++) {
    // Read the match scores
    $match1 = explode("x", trim(fgets(STDIN)));
    $match2 = explode("x", trim(fgets(STDIN)));

    // Call the determineWinner function to get the result
    $winner = determineWinner($match1, $match2);

    // Print the result
    echo $winner . "\n";
}
?>
