<?php
function fibonacci($n) {
    $sqrt5 = sqrt(5);
    $phi = (1 + $sqrt5) / 2;
    $psi = (1 - $sqrt5) / 2;
    return round((pow($phi, $n) - pow($psi, $n)) / $sqrt5, 1);
}

$n = intval(trim(fgets(STDIN)));
echo fibonacci($n);
?>